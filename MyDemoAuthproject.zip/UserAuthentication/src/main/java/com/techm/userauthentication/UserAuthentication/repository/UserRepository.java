/**
 * 
 */
package com.techm.userauthentication.UserAuthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techm.userauthentication.UserAuthentication.model.User;

/**
 * @author sawan505
 *
 */
public interface UserRepository extends JpaRepository<User, Long>{
	
	User findByUsername(String username);

}
