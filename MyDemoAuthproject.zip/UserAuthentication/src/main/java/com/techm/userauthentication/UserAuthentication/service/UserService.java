/**
 * 
 */
package com.techm.userauthentication.UserAuthentication.service;

import com.techm.userauthentication.UserAuthentication.model.User;

/**
 * @author sawan505
 *
 */
public interface UserService {

	void save(User user);

	User findByUsername(String username);

}
