/**
 * 
 */
package com.techm.userauthentication.UserAuthentication.service;

/**
 * @author sawan505
 *
 */
public interface SecurityService {
	
	String findLoggedInUsername();
	
	void autoLogin(String username, String password);

}
