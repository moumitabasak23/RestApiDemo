/**
 * 
 */
package com.techm.userauthentication.UserAuthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techm.userauthentication.UserAuthentication.model.Role;

/**
 * @author sawan505
 *
 */
public interface RoleRepository extends JpaRepository<Role, Long>{

}
